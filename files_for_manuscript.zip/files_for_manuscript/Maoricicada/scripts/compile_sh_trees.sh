~/newick-utils-1.6/src/nw_ed maoricicada.loci.treefile 'i & b == 0' o > maoricicada.loci_collapsed.treefile
