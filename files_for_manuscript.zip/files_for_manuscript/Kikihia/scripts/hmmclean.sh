#!/bin/bash
#SBATCH --job-name=hmmcleaner
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 16
#SBATCH --partition=general
#SBATCH --qos=general
#SBATCH --mem=100G
#SBATCH --mail-type=END
#SBATCH --mail-user=mark.stukel@uconn.edu
#SBATCH -o hmmclean_%j.out
#SBATCH -e hmmclean_%j.err
mkdir ./hmmcleaned/
module load hmmer/3.2.1
export PERL5LIB="/home/FCAM/jvailionis/perl5/lib/perl5"
for x in *.fas; do /isg/shared/apps/perl/5.28.0/bin/perl /home/FCAM/jvailionis/perl5/bin/HmmCleaner.pl $x -costs -0.75 -0.5 0.15 0.45; done
mv *hmm.* ./hmmcleaned/
