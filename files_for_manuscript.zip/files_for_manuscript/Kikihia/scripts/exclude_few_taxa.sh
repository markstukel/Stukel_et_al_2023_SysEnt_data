rm ./filtered/*
rm exclude.log
mkdir ./filtered/
for x in *.fas
do
  y=$(grep '>' $x | wc -l)
  if [ $y -ge 4 ] 
  then
    cp $x ./filtered/;
  else
    echo "$x had $y taxa, excluding" >> exclude.log
  fi
done
