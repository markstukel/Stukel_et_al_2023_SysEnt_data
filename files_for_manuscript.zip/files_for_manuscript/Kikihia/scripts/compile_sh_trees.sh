~/newick-utils-1.6/src/nw_ed kikihia.loci.treefile 'i & b == 0' o > kikihia.loci_collapsed.treefile
