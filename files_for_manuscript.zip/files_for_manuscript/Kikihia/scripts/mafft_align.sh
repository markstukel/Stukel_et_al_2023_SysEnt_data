#!/bin/bash
#SBATCH --job-name=mafft
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 16
#SBATCH --partition=general
#SBATCH --qos=general
#SBATCH --mail-type=END
#SBATCH --mem=100G
#SBATCH --mail-user=mark.stukel@uconn.edu
#SBATCH -o mafft_%j.out
#SBATCH -e mafft_%j.err 
module load mafft
mkdir aligned
for x in *.fas
do
einsi --thread 16 $x > ./aligned/$x
done
